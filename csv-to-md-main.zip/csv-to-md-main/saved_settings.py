"""This is your settings file."""

scraped_perou = {'addYAML': 'y',
 'column': {0: ['n'], 1: ['n'], 2: ['n'], 3: ['n']},
 'delimiter': ',',
 'fileNameCol': [2, 3],
 'fileNameColSeparator': ',',
 'fileNameLength': 60,
 'inlineYAML': 'n'}

