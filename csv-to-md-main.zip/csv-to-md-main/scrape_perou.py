import requests
from bs4 import BeautifulSoup
import pandas as pd

# Step 1: Send GET request to the site
url = 'https://perou.hellojames.co.uk/'
response = requests.get(url)

if response.status_code != 200:
    print(f"Failed to retrieve the webpage: {response.status_code}")
    exit()

# Step 2: Parse HTML
soup = BeautifulSoup(response.text, 'html.parser')

# Step 3: Find all 'polaroid' elements
items = soup.find_all(class_='polaroid')

data = []
for item in items:
    img_tag = item.find('img')
    
    # Default values
    img_src = ''
    hover_src = ''
    musician_name = ''
    band_name = ''

    if img_tag:
        # Get the static image src
        img_src = img_tag.get('src', '').strip()

        # Get the onmouseover image URL
        onmouseover_attr = img_tag.get('onmouseover', '')
        if "this.src=" in onmouseover_attr:
            # Extract the URL from the JS string
            start = onmouseover_attr.find("this.src=")
            quote_start = onmouseover_attr.find("'", start) + 1
            quote_end = onmouseover_attr.find("'", quote_start)
            hover_src = onmouseover_attr[quote_start:quote_end].strip()

    # Get the <p> tag and clean it
    p_tag = item.find('p')
    if p_tag:
        # Use .stripped_strings to get clean text parts without <br/>
        parts = list(p_tag.stripped_strings)
        if parts:
            musician_name = parts[0]
            if len(parts) > 1:
                band_name = parts[1]

    data.append([img_src, hover_src, musician_name, band_name])

# Step 4: Save to CSV
df = pd.DataFrame(data, columns=['Image Src', 'Hover Image Src', 'Musician Name', 'Band Name'])
df.to_csv('scraped_data.csv', index=False)

print("✅ Data scraped and saved to 'scraped_data.csv'")
