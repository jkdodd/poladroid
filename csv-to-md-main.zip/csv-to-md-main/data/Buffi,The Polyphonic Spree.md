---
Image_Src: ["assets/images/musician0977.png"]
Hover_Image_Src: null
Musician_Name: ["Buffi"]
Band_Name: ["The Polyphonic Spree"]
---
assets/images/musician0977.png

Buffi

The Polyphonic Spree