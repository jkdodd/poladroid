---
Image_Src: ["assets/images/musician2412.png"]
Hover_Image_Src: ["assets/images/musician2412.1.png"]
Musician_Name: ["Rob"]
Band_Name: ["Orange Goblin"]
---
assets/images/musician2412.png

assets/images/musician2412.1.png

Rob

Orange Goblin