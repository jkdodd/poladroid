---
Image_Src: ["assets/images/musician0274.png"]
Hover_Image_Src: null
Musician_Name: ["Derek"]
Band_Name: ["Big D & The Kids Table"]
---
assets/images/musician0274.png

Derek

Big D & The Kids Table