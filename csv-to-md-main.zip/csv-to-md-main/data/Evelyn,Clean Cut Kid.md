---
Image_Src: ["assets/images/musician1773.png"]
Hover_Image_Src: null
Musician_Name: ["Evelyn"]
Band_Name: ["Clean Cut Kid"]
---
assets/images/musician1773.png

Evelyn

Clean Cut Kid