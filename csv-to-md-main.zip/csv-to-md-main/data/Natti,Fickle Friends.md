---
Image_Src: ["assets/images/musician1812.png"]
Hover_Image_Src: null
Musician_Name: ["Natti"]
Band_Name: ["Fickle Friends"]
---
assets/images/musician1812.png

Natti

Fickle Friends