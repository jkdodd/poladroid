---
Image_Src: ["assets/images/musician2170.png"]
Hover_Image_Src: null
Musician_Name: ["Pape Oumar Diagne"]
Band_Name: null
---
assets/images/musician2170.png

Pape Oumar Diagne