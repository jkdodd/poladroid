---
Image_Src: ["assets/images/musician2309.png"]
Hover_Image_Src: ["assets/images/musician2309.1.png"]
Musician_Name: ["Giles"]
Band_Name: ["Leif Erikson"]
---
assets/images/musician2309.png

assets/images/musician2309.1.png

Giles

Leif Erikson