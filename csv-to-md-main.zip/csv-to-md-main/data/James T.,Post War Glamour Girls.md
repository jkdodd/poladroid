---
Image_Src: ["assets/images/musician2094.png"]
Hover_Image_Src: null
Musician_Name: ["James T."]
Band_Name: ["Post War Glamour Girls"]
---
assets/images/musician2094.png

James T.

Post War Glamour Girls