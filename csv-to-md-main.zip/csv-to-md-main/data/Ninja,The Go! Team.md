---
Image_Src: ["assets/images/musician2419.png"]
Hover_Image_Src: ["assets/images/musician2419.1.png"]
Musician_Name: ["Ninja"]
Band_Name: ["The Go! Team"]
---
assets/images/musician2419.png

assets/images/musician2419.1.png

Ninja

The Go! Team