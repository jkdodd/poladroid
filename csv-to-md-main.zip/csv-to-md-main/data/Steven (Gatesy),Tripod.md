---
Image_Src: ["assets/images/musician2476.png"]
Hover_Image_Src: null
Musician_Name: ["Steven (Gatesy)"]
Band_Name: ["Tripod"]
---
assets/images/musician2476.png

Steven (Gatesy)

Tripod