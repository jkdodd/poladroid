---
Image_Src: ["assets/images/musician1057.png"]
Hover_Image_Src: null
Musician_Name: ["Taylor"]
Band_Name: ["Paramore"]
---
assets/images/musician1057.png

Taylor

Paramore