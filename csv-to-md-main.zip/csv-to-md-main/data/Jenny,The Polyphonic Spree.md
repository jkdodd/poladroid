---
Image_Src: ["assets/images/musician0970.png"]
Hover_Image_Src: null
Musician_Name: ["Jenny"]
Band_Name: ["The Polyphonic Spree"]
---
assets/images/musician0970.png

Jenny

The Polyphonic Spree