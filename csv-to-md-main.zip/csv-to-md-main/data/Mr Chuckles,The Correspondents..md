---
Image_Src: ["assets/images/musician0218.png"]
Hover_Image_Src: null
Musician_Name: ["Mr Chuckles"]
Band_Name: ["The Correspondents."]
---
assets/images/musician0218.png

Mr Chuckles

The Correspondents.