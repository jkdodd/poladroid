---
Image_Src: ["assets/images/musician0149.png"]
Hover_Image_Src: null
Musician_Name: ["Klara"]
Band_Name: ["First Aid Kit."]
---
assets/images/musician0149.png

Klara

First Aid Kit.