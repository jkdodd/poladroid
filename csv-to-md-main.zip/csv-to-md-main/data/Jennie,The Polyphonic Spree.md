---
Image_Src: ["assets/images/musician0969.png"]
Hover_Image_Src: null
Musician_Name: ["Jennie"]
Band_Name: ["The Polyphonic Spree"]
---
assets/images/musician0969.png

Jennie

The Polyphonic Spree