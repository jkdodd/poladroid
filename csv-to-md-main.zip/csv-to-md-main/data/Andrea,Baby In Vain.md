---
Image_Src: ["assets/images/musician2276.png"]
Hover_Image_Src: null
Musician_Name: ["Andrea"]
Band_Name: ["Baby In Vain"]
---
assets/images/musician2276.png

Andrea

Baby In Vain