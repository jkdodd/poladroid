---
Image_Src: ["assets/images/musician1307.png"]
Hover_Image_Src: null
Musician_Name: ["Bridie"]
Band_Name: ["SOAK"]
---
assets/images/musician1307.png

Bridie

SOAK