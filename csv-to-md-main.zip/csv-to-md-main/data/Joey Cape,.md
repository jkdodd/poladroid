---
Image_Src: ["assets/images/musician1216.png"]
Hover_Image_Src: ["assets/images/musician1216.1.png"]
Musician_Name: ["Joey Cape"]
Band_Name: null
---
assets/images/musician1216.png

assets/images/musician1216.1.png

Joey Cape