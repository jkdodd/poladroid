---
Image_Src: ["assets/images/musician0521.png"]
Hover_Image_Src: null
Musician_Name: ["Camille"]
Band_Name: ["Caravan Palace"]
---
assets/images/musician0521.png

Camille

Caravan Palace