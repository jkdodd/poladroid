---
Image_Src: ["assets/images/musician0445.png"]
Hover_Image_Src: null
Musician_Name: ["Chilli"]
Band_Name: ["Palma Violets"]
---
assets/images/musician0445.png

Chilli

Palma Violets