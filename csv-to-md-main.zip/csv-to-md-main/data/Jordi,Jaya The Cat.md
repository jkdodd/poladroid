---
Image_Src: ["assets/images/musician0285.png"]
Hover_Image_Src: null
Musician_Name: ["Jordi"]
Band_Name: ["Jaya The Cat"]
---
assets/images/musician0285.png

Jordi

Jaya The Cat