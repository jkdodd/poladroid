---
Image_Src: ["assets/images/musician2319.png"]
Hover_Image_Src: null
Musician_Name: ["Christian"]
Band_Name: ["The Black Angels"]
---
assets/images/musician2319.png

Christian

The Black Angels