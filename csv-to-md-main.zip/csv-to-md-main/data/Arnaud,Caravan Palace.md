---
Image_Src: ["assets/images/musician0524.png"]
Hover_Image_Src: null
Musician_Name: ["Arnaud"]
Band_Name: ["Caravan Palace"]
---
assets/images/musician0524.png

Arnaud

Caravan Palace