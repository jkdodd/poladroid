---
Image_Src: ["assets/images/musician0547.png"]
Hover_Image_Src: null
Musician_Name: ["Kim"]
Band_Name: ["Chic"]
---
assets/images/musician0547.png

Kim

Chic