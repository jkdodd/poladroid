---
Image_Src: ["assets/images/musician2226.png"]
Hover_Image_Src: ["assets/images/musician2226.1.png"]
Musician_Name: ["Lee"]
Band_Name: ["Idles"]
---
assets/images/musician2226.png

assets/images/musician2226.1.png

Lee

Idles