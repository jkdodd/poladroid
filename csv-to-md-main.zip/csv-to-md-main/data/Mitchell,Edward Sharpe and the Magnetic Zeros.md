---
Image_Src: ["assets/images/musician1729.png"]
Hover_Image_Src: null
Musician_Name: ["Mitchell"]
Band_Name: ["Edward Sharpe and the Magnetic Zeros"]
---
assets/images/musician1729.png

Mitchell

Edward Sharpe and the Magnetic Zeros