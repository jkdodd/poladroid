---
Image_Src: ["assets/images/musician1532.png"]
Hover_Image_Src: null
Musician_Name: ["Felix"]
Band_Name: ["Hot Chip"]
---
assets/images/musician1532.png

Felix

Hot Chip