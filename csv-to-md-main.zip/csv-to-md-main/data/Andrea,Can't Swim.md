---
Image_Src: ["assets/images/musician2074.png"]
Hover_Image_Src: null
Musician_Name: ["Andrea"]
Band_Name: ["Can't Swim"]
---
assets/images/musician2074.png

Andrea

Can't Swim