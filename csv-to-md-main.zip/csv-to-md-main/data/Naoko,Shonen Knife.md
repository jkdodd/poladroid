---
Image_Src: ["assets/images/musician1634.png"]
Hover_Image_Src: null
Musician_Name: ["Naoko"]
Band_Name: ["Shonen Knife"]
---
assets/images/musician1634.png

Naoko

Shonen Knife