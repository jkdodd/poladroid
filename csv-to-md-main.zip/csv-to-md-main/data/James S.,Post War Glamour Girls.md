---
Image_Src: ["assets/images/musician2092.png"]
Hover_Image_Src: null
Musician_Name: ["James S."]
Band_Name: ["Post War Glamour Girls"]
---
assets/images/musician2092.png

James S.

Post War Glamour Girls