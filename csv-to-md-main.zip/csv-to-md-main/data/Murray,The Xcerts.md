---
Image_Src: ["assets/images/musician1732.png"]
Hover_Image_Src: null
Musician_Name: ["Murray"]
Band_Name: ["The Xcerts"]
---
assets/images/musician1732.png

Murray

The Xcerts