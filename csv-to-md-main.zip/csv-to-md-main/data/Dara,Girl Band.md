---
Image_Src: ["assets/images/musician1958.png"]
Hover_Image_Src: null
Musician_Name: ["Dara"]
Band_Name: ["Girl Band"]
---
assets/images/musician1958.png

Dara

Girl Band