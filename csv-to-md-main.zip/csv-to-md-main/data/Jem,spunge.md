---
Image_Src: ["assets/images/musician2400.png"]
Hover_Image_Src: ["assets/images/musician2400.1.png"]
Musician_Name: ["Jem"]
Band_Name: ["[spunge]"]
---
assets/images/musician2400.png

assets/images/musician2400.1.png

Jem

[spunge]