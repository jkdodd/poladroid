---
Image_Src: ["assets/images/musician2246.png"]
Hover_Image_Src: null
Musician_Name: ["Charlie"]
Band_Name: ["Pale Waves"]
---
assets/images/musician2246.png

Charlie

Pale Waves