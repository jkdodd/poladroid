---
Image_Src: ["assets/images/musician0021.png"]
Hover_Image_Src: null
Musician_Name: ["Scroobius Pip"]
Band_Name: ["Dan Le Sac vs Scroobius Pip."]
---
assets/images/musician0021.png

Scroobius Pip

Dan Le Sac vs Scroobius Pip.