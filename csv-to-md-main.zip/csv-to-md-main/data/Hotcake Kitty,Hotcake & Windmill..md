---
Image_Src: ["assets/images/musician0219.png"]
Hover_Image_Src: null
Musician_Name: ["Hotcake Kitty"]
Band_Name: ["Hotcake & Windmill."]
---
assets/images/musician0219.png

Hotcake Kitty

Hotcake & Windmill.