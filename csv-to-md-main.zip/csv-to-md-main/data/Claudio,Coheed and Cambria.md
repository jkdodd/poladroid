---
Image_Src: ["assets/images/musician1740.png"]
Hover_Image_Src: null
Musician_Name: ["Claudio"]
Band_Name: ["Coheed and Cambria"]
---
assets/images/musician1740.png

Claudio

Coheed and Cambria