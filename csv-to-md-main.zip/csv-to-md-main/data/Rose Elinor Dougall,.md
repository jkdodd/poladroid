---
Image_Src: ["assets/images/musician1972.png"]
Hover_Image_Src: ["assets/images/musician1972.1.png"]
Musician_Name: ["Rose Elinor Dougall"]
Band_Name: null
---
assets/images/musician1972.png

assets/images/musician1972.1.png

Rose Elinor Dougall