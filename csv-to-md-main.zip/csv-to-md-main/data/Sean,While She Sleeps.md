---
Image_Src: ["assets/images/musician1478.png"]
Hover_Image_Src: null
Musician_Name: ["Sean"]
Band_Name: ["While She Sleeps"]
---
assets/images/musician1478.png

Sean

While She Sleeps