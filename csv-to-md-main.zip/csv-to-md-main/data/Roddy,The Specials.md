---
Image_Src: ["assets/images/musician2428.3.png"]
Hover_Image_Src: null
Musician_Name: ["Roddy"]
Band_Name: ["The Specials"]
---
assets/images/musician2428.3.png

Roddy

The Specials