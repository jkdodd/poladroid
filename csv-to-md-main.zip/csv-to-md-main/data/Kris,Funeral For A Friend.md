---
Image_Src: ["assets/images/musician1289.png"]
Hover_Image_Src: null
Musician_Name: ["Kris"]
Band_Name: ["Funeral For A Friend"]
---
assets/images/musician1289.png

Kris

Funeral For A Friend