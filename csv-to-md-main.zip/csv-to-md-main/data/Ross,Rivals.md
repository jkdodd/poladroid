---
Image_Src: ["assets/images/musician0432.png"]
Hover_Image_Src: null
Musician_Name: ["Ross"]
Band_Name: ["Rivals"]
---
assets/images/musician0432.png

Ross

Rivals