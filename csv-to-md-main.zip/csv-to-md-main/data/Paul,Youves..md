---
Image_Src: ["assets/images/musician0111.png"]
Hover_Image_Src: null
Musician_Name: ["Paul"]
Band_Name: ["Youves."]
---
assets/images/musician0111.png

Paul

Youves.