---
Image_Src: ["assets/images/musician1880.png"]
Hover_Image_Src: null
Musician_Name: ["Gerard"]
Band_Name: ["Teenage Fanclub"]
---
assets/images/musician1880.png

Gerard

Teenage Fanclub