---
Image_Src: ["assets/images/musician0598.png"]
Hover_Image_Src: null
Musician_Name: ["Daniel"]
Band_Name: ["The Creepshow"]
---
assets/images/musician0598.png

Daniel

The Creepshow