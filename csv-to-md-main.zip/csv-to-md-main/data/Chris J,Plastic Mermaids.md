---
Image_Src: ["assets/images/musician2152.png"]
Hover_Image_Src: null
Musician_Name: ["Chris J"]
Band_Name: ["Plastic Mermaids"]
---
assets/images/musician2152.png

Chris J

Plastic Mermaids