---
Image_Src: ["assets/images/musician0870.png"]
Hover_Image_Src: null
Musician_Name: ["Eli "Paperboy" Reed"]
Band_Name: null
---
assets/images/musician0870.png

Eli "Paperboy" Reed