---
Image_Src: ["assets/images/musician2413.png"]
Hover_Image_Src: null
Musician_Name: ["Chris"]
Band_Name: ["Orange Goblin"]
---
assets/images/musician2413.png

Chris

Orange Goblin