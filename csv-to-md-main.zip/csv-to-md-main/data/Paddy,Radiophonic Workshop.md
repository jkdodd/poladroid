---
Image_Src: ["assets/images/musician2159.png"]
Hover_Image_Src: null
Musician_Name: ["Paddy"]
Band_Name: ["Radiophonic Workshop"]
---
assets/images/musician2159.png

Paddy

Radiophonic Workshop