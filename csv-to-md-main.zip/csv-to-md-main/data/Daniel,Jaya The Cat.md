---
Image_Src: ["assets/images/musician0282.png"]
Hover_Image_Src: null
Musician_Name: ["Daniel"]
Band_Name: ["Jaya The Cat"]
---
assets/images/musician0282.png

Daniel

Jaya The Cat