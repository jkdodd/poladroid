---
Image_Src: ["assets/images/musician0374.png"]
Hover_Image_Src: null
Musician_Name: ["Dave"]
Band_Name: ["Eagles Of Death Metal"]
---
assets/images/musician0374.png

Dave

Eagles Of Death Metal