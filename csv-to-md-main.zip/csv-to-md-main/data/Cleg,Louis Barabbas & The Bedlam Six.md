---
Image_Src: ["assets/images/musician1887.png"]
Hover_Image_Src: null
Musician_Name: ["Cleg"]
Band_Name: ["Louis Barabbas & The Bedlam Six"]
---
assets/images/musician1887.png

Cleg

Louis Barabbas & The Bedlam Six