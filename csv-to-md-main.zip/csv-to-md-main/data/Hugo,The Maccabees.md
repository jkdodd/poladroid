---
Image_Src: ["assets/images/musician1572.png"]
Hover_Image_Src: ["assets/images/musician0087.png"]
Musician_Name: ["Hugo"]
Band_Name: ["The Maccabees"]
---
assets/images/musician1572.png

assets/images/musician0087.png

Hugo

The Maccabees