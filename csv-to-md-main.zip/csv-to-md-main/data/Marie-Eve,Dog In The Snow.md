---
Image_Src: ["assets/images/musician0844.png"]
Hover_Image_Src: null
Musician_Name: ["Marie-Eve"]
Band_Name: ["Dog In The Snow"]
---
assets/images/musician0844.png

Marie-Eve

Dog In The Snow