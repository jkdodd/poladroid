---
Image_Src: ["assets/images/musician0631.png"]
Hover_Image_Src: null
Musician_Name: ["Dan"]
Band_Name: ["Imagine Dragons"]
---
assets/images/musician0631.png

Dan

Imagine Dragons