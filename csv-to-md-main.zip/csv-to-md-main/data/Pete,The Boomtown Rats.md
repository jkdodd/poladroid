---
Image_Src: ["assets/images/musician1122.png"]
Hover_Image_Src: null
Musician_Name: ["Pete"]
Band_Name: ["The Boomtown Rats"]
---
assets/images/musician1122.png

Pete

The Boomtown Rats