---
Image_Src: ["assets/images/musician0065.png"]
Hover_Image_Src: null
Musician_Name: ["Mike"]
Band_Name: ["Streetlight Manifesto."]
---
assets/images/musician0065.png

Mike

Streetlight Manifesto.