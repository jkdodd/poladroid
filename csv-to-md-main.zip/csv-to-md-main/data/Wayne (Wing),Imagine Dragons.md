---
Image_Src: ["assets/images/musician0632.png"]
Hover_Image_Src: null
Musician_Name: ["Wayne (Wing)"]
Band_Name: ["Imagine Dragons"]
---
assets/images/musician0632.png

Wayne (Wing)

Imagine Dragons