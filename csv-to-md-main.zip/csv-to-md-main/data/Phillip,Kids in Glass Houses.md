---
Image_Src: ["assets/images/musician0328.png"]
Hover_Image_Src: null
Musician_Name: ["Phillip"]
Band_Name: ["Kids in Glass Houses"]
---
assets/images/musician0328.png

Phillip

Kids in Glass Houses