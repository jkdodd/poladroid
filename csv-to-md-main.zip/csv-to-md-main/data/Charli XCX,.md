---
Image_Src: ["assets/images/musician0662.png"]
Hover_Image_Src: null
Musician_Name: ["Charli XCX"]
Band_Name: null
---
assets/images/musician0662.png

Charli XCX