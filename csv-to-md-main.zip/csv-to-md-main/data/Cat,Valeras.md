---
Image_Src: ["assets/images/musician2482.png"]
Hover_Image_Src: null
Musician_Name: ["Cat"]
Band_Name: ["Valeras"]
---
assets/images/musician2482.png

Cat

Valeras