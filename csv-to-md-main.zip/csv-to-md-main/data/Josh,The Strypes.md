---
Image_Src: ["assets/images/musician0692.png"]
Hover_Image_Src: null
Musician_Name: ["Josh"]
Band_Name: ["The Strypes"]
---
assets/images/musician0692.png

Josh

The Strypes