---
Image_Src: ["assets/images/musician1045.png"]
Hover_Image_Src: null
Musician_Name: ["Kwake Bass"]
Band_Name: ["(Kate Tempest)"]
---
assets/images/musician1045.png

Kwake Bass

(Kate Tempest)