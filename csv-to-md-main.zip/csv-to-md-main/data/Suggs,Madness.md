---
Image_Src: ["assets/images/musician0565.png"]
Hover_Image_Src: null
Musician_Name: ["Suggs"]
Band_Name: ["Madness"]
---
assets/images/musician0565.png

Suggs

Madness