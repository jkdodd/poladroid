---
Image_Src: ["assets/images/musician1873.png"]
Hover_Image_Src: ["assets/images/musician1873.1.png"]
Musician_Name: ["Henry "Hen Dogg"]
Band_Name: ["The Sugarhill Gang"]
---
assets/images/musician1873.png

assets/images/musician1873.1.png

Henry "Hen Dogg"

The Sugarhill Gang