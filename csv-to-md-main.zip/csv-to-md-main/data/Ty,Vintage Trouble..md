---
Image_Src: ["assets/images/musician0235.png"]
Hover_Image_Src: null
Musician_Name: ["Ty"]
Band_Name: ["Vintage Trouble."]
---
assets/images/musician0235.png

Ty

Vintage Trouble.