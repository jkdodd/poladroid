---
Image_Src: ["assets/images/musician0640.png"]
Hover_Image_Src: null
Musician_Name: ["Elliot"]
Band_Name: ["Editors"]
---
assets/images/musician0640.png

Elliot

Editors