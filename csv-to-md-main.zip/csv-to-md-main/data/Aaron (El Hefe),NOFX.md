---
Image_Src: ["assets/images/musician2486.png"]
Hover_Image_Src: null
Musician_Name: ["Aaron (El Hefe)"]
Band_Name: ["NOFX"]
---
assets/images/musician2486.png

Aaron (El Hefe)

NOFX