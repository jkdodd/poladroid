---
Image_Src: ["assets/images/musician0076.png"]
Hover_Image_Src: null
Musician_Name: ["Tom"]
Band_Name: ["The Rumble Strips."]
---
assets/images/musician0076.png

Tom

The Rumble Strips.