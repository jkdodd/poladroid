---
Image_Src: ["assets/images/musician1378.png"]
Hover_Image_Src: null
Musician_Name: ["Martin"]
Band_Name: ["Eliza And The Bear"]
---
assets/images/musician1378.png

Martin

Eliza And The Bear