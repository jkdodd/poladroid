---
Image_Src: ["assets/images/musician2277.png"]
Hover_Image_Src: null
Musician_Name: ["Lola"]
Band_Name: ["Baby In Vain"]
---
assets/images/musician2277.png

Lola

Baby In Vain