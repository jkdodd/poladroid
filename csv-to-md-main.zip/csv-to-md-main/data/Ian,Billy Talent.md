---
Image_Src: ["assets/images/musician0396.png"]
Hover_Image_Src: null
Musician_Name: ["Ian"]
Band_Name: ["Billy Talent"]
---
assets/images/musician0396.png

Ian

Billy Talent