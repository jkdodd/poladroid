---
Image_Src: ["assets/images/musician0379.png"]
Hover_Image_Src: null
Musician_Name: ["Arni"]
Band_Name: ["The Vaccines"]
---
assets/images/musician0379.png

Arni

The Vaccines