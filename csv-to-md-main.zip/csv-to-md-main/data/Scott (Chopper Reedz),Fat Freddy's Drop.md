---
Image_Src: ["assets/images/musician1115.png"]
Hover_Image_Src: ["assets/images/musician1115.1.png"]
Musician_Name: ["Scott (Chopper Reedz)"]
Band_Name: ["Fat Freddy's Drop"]
---
assets/images/musician1115.png

assets/images/musician1115.1.png

Scott (Chopper Reedz)

Fat Freddy's Drop