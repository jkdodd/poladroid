---
Image_Src: ["assets/images/musician0488.png"]
Hover_Image_Src: null
Musician_Name: ["Mario (Ruby Mars)"]
Band_Name: ["Rocket From The Crypt"]
---
assets/images/musician0488.png

Mario (Ruby Mars)

Rocket From The Crypt