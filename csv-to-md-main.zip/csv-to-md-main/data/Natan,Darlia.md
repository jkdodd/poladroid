---
Image_Src: ["assets/images/musician1049.png"]
Hover_Image_Src: null
Musician_Name: ["Natan"]
Band_Name: ["Darlia"]
---
assets/images/musician1049.png

Natan

Darlia