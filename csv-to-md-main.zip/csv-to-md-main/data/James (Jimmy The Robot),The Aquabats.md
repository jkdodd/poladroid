---
Image_Src: ["assets/images/musician0478.png"]
Hover_Image_Src: null
Musician_Name: ["James (Jimmy The Robot)"]
Band_Name: ["The Aquabats"]
---
assets/images/musician0478.png

James (Jimmy The Robot)

The Aquabats