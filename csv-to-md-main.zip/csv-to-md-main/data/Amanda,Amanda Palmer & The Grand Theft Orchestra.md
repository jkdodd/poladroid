---
Image_Src: ["assets/images/musician0557.png"]
Hover_Image_Src: null
Musician_Name: ["Amanda"]
Band_Name: ["Amanda Palmer & The Grand Theft Orchestra"]
---
assets/images/musician0557.png

Amanda

Amanda Palmer & The Grand Theft Orchestra