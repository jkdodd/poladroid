---
Image_Src: ["assets/images/musician2245.png"]
Hover_Image_Src: null
Musician_Name: ["Sigrid"]
Band_Name: null
---
assets/images/musician2245.png

Sigrid