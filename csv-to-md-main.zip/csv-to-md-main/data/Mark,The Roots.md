---
Image_Src: ["assets/images/musician1332.png"]
Hover_Image_Src: null
Musician_Name: ["Mark"]
Band_Name: ["The Roots"]
---
assets/images/musician1332.png

Mark

The Roots