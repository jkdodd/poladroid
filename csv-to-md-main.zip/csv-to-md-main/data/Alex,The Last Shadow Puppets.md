---
Image_Src: ["assets/images/musician1701.png"]
Hover_Image_Src: null
Musician_Name: ["Alex"]
Band_Name: ["The Last Shadow Puppets"]
---
assets/images/musician1701.png

Alex

The Last Shadow Puppets