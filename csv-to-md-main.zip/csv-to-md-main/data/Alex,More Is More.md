---
Image_Src: ["assets/images/musician1949.png"]
Hover_Image_Src: null
Musician_Name: ["Alex"]
Band_Name: ["More Is More"]
---
assets/images/musician1949.png

Alex

More Is More