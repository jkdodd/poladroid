---
Image_Src: ["assets/images/musician0190.png"]
Hover_Image_Src: null
Musician_Name: ["Ross"]
Band_Name: ["The Cribs."]
---
assets/images/musician0190.png

Ross

The Cribs.