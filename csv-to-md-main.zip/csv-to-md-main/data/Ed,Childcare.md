---
Image_Src: ["assets/images/musician1497.png"]
Hover_Image_Src: null
Musician_Name: ["Ed"]
Band_Name: ["Childcare"]
---
assets/images/musician1497.png

Ed

Childcare