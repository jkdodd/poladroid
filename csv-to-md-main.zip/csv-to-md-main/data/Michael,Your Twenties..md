---
Image_Src: ["assets/images/musician0060.png"]
Hover_Image_Src: null
Musician_Name: ["Michael"]
Band_Name: ["Your Twenties."]
---
assets/images/musician0060.png

Michael

Your Twenties.