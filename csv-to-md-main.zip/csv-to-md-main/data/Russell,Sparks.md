---
Image_Src: ["assets/images/musician2311.png"]
Hover_Image_Src: null
Musician_Name: ["Russell"]
Band_Name: ["Sparks"]
---
assets/images/musician2311.png

Russell

Sparks