---
Image_Src: ["assets/images/musician1535.png"]
Hover_Image_Src: null
Musician_Name: ["Joe"]
Band_Name: ["Hot Chip"]
---
assets/images/musician1535.png

Joe

Hot Chip