---
Image_Src: ["assets/images/musician2068.png"]
Hover_Image_Src: null
Musician_Name: ["Soph"]
Band_Name: ["The Big Moon"]
---
assets/images/musician2068.png

Soph

The Big Moon