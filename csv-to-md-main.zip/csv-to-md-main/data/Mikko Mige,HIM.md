---
Image_Src: ["assets/images/musician0725.png"]
Hover_Image_Src: null
Musician_Name: ["Mikko "Mige"]
Band_Name: ["HIM"]
---
assets/images/musician0725.png

Mikko "Mige"

HIM