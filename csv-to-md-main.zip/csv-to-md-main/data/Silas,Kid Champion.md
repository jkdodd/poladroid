---
Image_Src: ["assets/images/musician0383.png"]
Hover_Image_Src: null
Musician_Name: ["Silas"]
Band_Name: ["Kid Champion"]
---
assets/images/musician0383.png

Silas

Kid Champion