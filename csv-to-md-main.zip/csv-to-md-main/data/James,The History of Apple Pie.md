---
Image_Src: ["assets/images/musician0288.png"]
Hover_Image_Src: null
Musician_Name: ["James"]
Band_Name: ["The History of Apple Pie"]
---
assets/images/musician0288.png

James

The History of Apple Pie