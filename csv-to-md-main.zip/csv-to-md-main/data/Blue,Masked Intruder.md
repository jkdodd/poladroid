---
Image_Src: ["assets/images/musician1082.png"]
Hover_Image_Src: null
Musician_Name: ["Blue"]
Band_Name: ["Masked Intruder"]
---
assets/images/musician1082.png

Blue

Masked Intruder