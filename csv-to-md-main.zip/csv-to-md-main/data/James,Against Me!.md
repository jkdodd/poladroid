---
Image_Src: ["assets/images/musician1953.png"]
Hover_Image_Src: null
Musician_Name: ["James"]
Band_Name: ["Against Me!"]
---
assets/images/musician1953.png

James

Against Me!