---
Image_Src: ["assets/images/musician0828.png"]
Hover_Image_Src: null
Musician_Name: ["Kim Churchill"]
Band_Name: null
---
assets/images/musician0828.png

Kim Churchill