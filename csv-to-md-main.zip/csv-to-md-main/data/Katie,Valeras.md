---
Image_Src: ["assets/images/musician2481.png"]
Hover_Image_Src: null
Musician_Name: ["Katie"]
Band_Name: ["Valeras"]
---
assets/images/musician2481.png

Katie

Valeras