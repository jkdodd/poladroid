---
Image_Src: ["assets/images/musician0878.png"]
Hover_Image_Src: null
Musician_Name: ["Charlie"]
Band_Name: ["Crocodiles"]
---
assets/images/musician0878.png

Charlie

Crocodiles