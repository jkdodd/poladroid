---
Image_Src: ["assets/images/musician0520.png"]
Hover_Image_Src: null
Musician_Name: ["Charles"]
Band_Name: ["Caravan Palace"]
---
assets/images/musician0520.png

Charles

Caravan Palace