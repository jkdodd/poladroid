---
Image_Src: ["assets/images/musician2150.png"]
Hover_Image_Src: null
Musician_Name: ["Jamie"]
Band_Name: ["Plastic Mermaids"]
---
assets/images/musician2150.png

Jamie

Plastic Mermaids