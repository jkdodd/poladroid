---
Image_Src: ["assets/images/musician0255.png"]
Hover_Image_Src: null
Musician_Name: ["Gabrielle"]
Band_Name: ["Wheatus"]
---
assets/images/musician0255.png

Gabrielle

Wheatus