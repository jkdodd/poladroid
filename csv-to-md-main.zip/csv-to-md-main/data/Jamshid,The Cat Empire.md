---
Image_Src: ["assets/images/musician0413.png"]
Hover_Image_Src: null
Musician_Name: ["Jamshid"]
Band_Name: ["The Cat Empire"]
---
assets/images/musician0413.png

Jamshid

The Cat Empire