---
Image_Src: ["assets/images/musician0107.png"]
Hover_Image_Src: null
Musician_Name: ["Eddie"]
Band_Name: ["Art Brut."]
---
assets/images/musician0107.png

Eddie

Art Brut.