---
Image_Src: ["assets/images/musician0868.png"]
Hover_Image_Src: null
Musician_Name: ["Dave"]
Band_Name: ["Chas & Dave"]
---
assets/images/musician0868.png

Dave

Chas & Dave