---
Image_Src: ["assets/images/musician1063.png"]
Hover_Image_Src: null
Musician_Name: ["Christian (Chris Dangerous)"]
Band_Name: ["The Hives"]
---
assets/images/musician1063.png

Christian (Chris Dangerous)

The Hives