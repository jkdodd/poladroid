---
Image_Src: ["assets/images/musician1242.png"]
Hover_Image_Src: null
Musician_Name: ["Rival"]
Band_Name: null
---
assets/images/musician1242.png

Rival