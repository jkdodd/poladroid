---
Image_Src: ["assets/images/musician1468.png"]
Hover_Image_Src: null
Musician_Name: ["Magnus"]
Band_Name: ["Refused"]
---
assets/images/musician1468.png

Magnus

Refused