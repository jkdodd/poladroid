---
Image_Src: ["assets/images/musician2480.png"]
Hover_Image_Src: null
Musician_Name: ["Max"]
Band_Name: ["Valeras"]
---
assets/images/musician2480.png

Max

Valeras