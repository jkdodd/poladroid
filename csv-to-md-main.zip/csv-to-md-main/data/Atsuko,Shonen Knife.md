---
Image_Src: ["assets/images/musician1633.png"]
Hover_Image_Src: null
Musician_Name: ["Atsuko"]
Band_Name: ["Shonen Knife"]
---
assets/images/musician1633.png

Atsuko

Shonen Knife