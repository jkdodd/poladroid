---
Image_Src: ["assets/images/musician2269.png"]
Hover_Image_Src: null
Musician_Name: ["Clemens"]
Band_Name: ["Milky Chance"]
---
assets/images/musician2269.png

Clemens

Milky Chance