---
Image_Src: ["assets/images/musician0141.1.png"]
Hover_Image_Src: null
Musician_Name: ["Lu"]
Band_Name: ["Soundmouse."]
---
assets/images/musician0141.1.png

Lu

Soundmouse.