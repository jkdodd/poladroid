---
Image_Src: ["assets/images/musician1784.png"]
Hover_Image_Src: null
Musician_Name: ["Kristian"]
Band_Name: ["The Magic Gang"]
---
assets/images/musician1784.png

Kristian

The Magic Gang