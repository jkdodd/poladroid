---
Image_Src: ["assets/images/musician0254.png"]
Hover_Image_Src: null
Musician_Name: ["Ken"]
Band_Name: ["Wheatus"]
---
assets/images/musician0254.png

Ken

Wheatus