---
Image_Src: ["assets/images/musician1964.png"]
Hover_Image_Src: ["assets/images/musician1964.1.png"]
Musician_Name: ["Soph"]
Band_Name: ["Our Girl"]
---
assets/images/musician1964.png

assets/images/musician1964.1.png

Soph

Our Girl