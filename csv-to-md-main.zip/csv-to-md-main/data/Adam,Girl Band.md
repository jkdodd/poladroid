---
Image_Src: ["assets/images/musician1956.png"]
Hover_Image_Src: null
Musician_Name: ["Adam"]
Band_Name: ["Girl Band"]
---
assets/images/musician1956.png

Adam

Girl Band