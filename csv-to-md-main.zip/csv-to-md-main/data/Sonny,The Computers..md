---
Image_Src: ["assets/images/musician0245.png"]
Hover_Image_Src: null
Musician_Name: ["Sonny"]
Band_Name: ["The Computers."]
---
assets/images/musician0245.png

Sonny

The Computers.