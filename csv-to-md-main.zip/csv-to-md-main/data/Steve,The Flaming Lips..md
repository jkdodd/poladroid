---
Image_Src: ["assets/images/musician0943.png"]
Hover_Image_Src: null
Musician_Name: ["Steve"]
Band_Name: ["The Flaming Lips."]
---
assets/images/musician0943.png

Steve

The Flaming Lips.