---
Image_Src: ["assets/images/musician0208.png"]
Hover_Image_Src: null
Musician_Name: ["Lucy Rose"]
Band_Name: null
---
assets/images/musician0208.png

Lucy Rose