---
Image_Src: ["assets/images/musician0944.png"]
Hover_Image_Src: null
Musician_Name: ["Jake"]
Band_Name: ["The Flaming Lips."]
---
assets/images/musician0944.png

Jake

The Flaming Lips.