---
Image_Src: ["assets/images/musician0691.png"]
Hover_Image_Src: null
Musician_Name: ["Evan"]
Band_Name: ["The Strypes"]
---
assets/images/musician0691.png

Evan

The Strypes