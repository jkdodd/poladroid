---
Image_Src: ["assets/images/musician0032.png"]
Hover_Image_Src: null
Musician_Name: ["Jamie"]
Band_Name: ["The King Blues."]
---
assets/images/musician0032.png

Jamie

The King Blues.