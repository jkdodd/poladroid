---
Image_Src: ["assets/images/musician0702.png"]
Hover_Image_Src: null
Musician_Name: ["Harry"]
Band_Name: ["Keston Cobblers Club"]
---
assets/images/musician0702.png

Harry

Keston Cobblers Club