---
Image_Src: ["assets/images/musician0023.png"]
Hover_Image_Src: null
Musician_Name: ["Jemina"]
Band_Name: ["Be Your Own Pet."]
---
assets/images/musician0023.png

Jemina

Be Your Own Pet.