---
Image_Src: ["assets/images/musician0737.png"]
Hover_Image_Src: null
Musician_Name: ["Emily"]
Band_Name: ["Warpaint"]
---
assets/images/musician0737.png

Emily

Warpaint