---
Image_Src: ["assets/images/musician0075.png"]
Hover_Image_Src: null
Musician_Name: ["Henry"]
Band_Name: ["The Rumble Strips."]
---
assets/images/musician0075.png

Henry

The Rumble Strips.