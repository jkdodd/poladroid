---
Image_Src: ["assets/images/musician0030.png"]
Hover_Image_Src: null
Musician_Name: ["Fruitbag"]
Band_Name: ["The King Blues."]
---
assets/images/musician0030.png

Fruitbag

The King Blues.