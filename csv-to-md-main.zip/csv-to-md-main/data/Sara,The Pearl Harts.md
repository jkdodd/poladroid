---
Image_Src: ["assets/images/musician1190.png"]
Hover_Image_Src: null
Musician_Name: ["Sara"]
Band_Name: ["The Pearl Harts"]
---
assets/images/musician1190.png

Sara

The Pearl Harts